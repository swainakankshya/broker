import { createContext, useContext, useState, useEffect } from "react";
import { getPagedInvoices } from "../api/invoiceApi";

const PaginationContext = createContext(null);

export const PaginationProvider = ({ children }) => {

  const [records, setRecords] = useState([]);
  const [activeFilters, setActiveFilters] = useState({});
  const [currentRecordIndex, setCurrentRecordIndex] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);

 useEffect(() => {
  loadInitialRecords(currentPage, activeFilters);
}, [currentPage, activeFilters]);

 const loadInitialRecords = async (
  page = 1,
  filters = activeFilters,
  sortField = null,
  sortOrder = null
) => {
  try {

    const data = await getPagedInvoices(
  page,
  100,
  filters,
  sortField,
  sortOrder
);

console.log("DATA FROM API:", data);

setRecords(data.records || []);
setTotalRecords(data.totalRecords || 0);   // ⭐ IMPORTANT

// reset to first record
setCurrentRecordIndex(0);

  } catch (err) {
    console.error("Pagination load error", err);
  }
};

  // ===== RECORD LEVEL NAVIGATION =====

  const handleRecordNext = () => {
    setCurrentRecordIndex(prev =>
      prev < records.length - 1 ? prev + 1 : prev
    );
  };

  const handleRecordPrev = () => {
    setCurrentRecordIndex(prev =>
      prev > 0 ? prev - 1 : prev
    );
  };

  const handleFirstInvoice = () => {
    setCurrentRecordIndex(0);
  };

  const handleLastInvoice = () => {
    setCurrentRecordIndex(records.length - 1);
  };

 return (
  <PaginationContext.Provider
    value={{
      records,
      currentRecordIndex,
      currentPage,
      setRecords,
      totalRecords,
setCurrentPage, 
      
      activeFilters,
      setActiveFilters,
      setCurrentRecordIndex,
      handleRecordNext,
      handleRecordPrev,
      handleFirstInvoice,
      handleLastInvoice,
      loadInitialRecords
    }}
  >
    {children}
  </PaginationContext.Provider>
);
};

export const usePagination = () => useContext(PaginationContext);